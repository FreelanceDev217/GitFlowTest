
class ApiManager {

    // request:
    //    cmduid
    //    request
    //    cmd
    //    data
    //    onComplete
    //    onError
    //    loader
    //    loaderTarget
    //    allowUserCancel
    //    contentType
    //    timeOut
    //    passData


    constructor() {
        this.requests = [];
    }


    callApi(cmd, data = null, onComplete = null, onError = null, useLoader = false, loaderTarget = "body", allowUserCancel = false, contentType='json', timeOut = null, passData = null, async = true, apiURL = null) {

        if (data == null) {
            data = {};
        }
        data.cmd = cmd;
        data.cmduid = this.guid();

        var dataJSON = JSON.stringify(data);
        data = {forceJSON:1, jsondata: dataJSON};

     //   console.log('call API with', data);

        var loader = null;
        if (useLoader) {
            if (loaderTarget=="body") {
                loader = new main.ProgressPopup('en cours...');
                loader.open();
            } else {
                loader = this.createLoader( $(loaderTarget) );
            }
        }

        var fdone = this.callDone.bind(this);
        var ffail = this.callFail.bind(this);

        var request = $.ajax({
            url: (apiURL==null) ? newApiUrl : apiURL,
            method: "POST",
            data: data,
            dataType: contentType,
            async: async,

            timeout: ((timeOut==null) ? 0 : timeOut),
            success: fdone,
            error: ffail,            
        });

//        request.done(fdone);
//        request.fail(ffail);

        this.requests.push({
            cmduid: data.cmduid,
            request: request,
            cmd: cmd,
            data: data,
            onComplete: onComplete,
            onError: onError,
            loader: loader,
            loaderTarget: loaderTarget,
            allowUserCancel: allowUserCancel,
            contentType: contentType,
            timeOut: timeOut,
            passData: passData,
        });

    }

    callDone(data, textStatus, jqXHR) {
        // console.log('call DONE');
        // console.log(jqXHR);

        var sourceRequest = this.findRequest(jqXHR);
        // console.log('find:');
        // console.log(sourceRequest);

        if (sourceRequest.onComplete != null) {
            if (sourceRequest.passData == null) {
                sourceRequest.onComplete(data);
            } else {
                sourceRequest.onComplete(data, sourceRequest.passData);
            }
        }
        this.endCall(sourceRequest);
    }

    callFail(jqXHR, textStatus) {
        // console.log('call Failed');
        alert( "Request failed: " + textStatus );

        var sourceRequest = this.findRequest(jqXHR);
        this.endCall(sourceRequest);
    }

    endCall(sourceRequest) {
        if (sourceRequest.loader) {
            if (sourceRequest.loaderTarget=="body") {
                sourceRequest.loader.close();
            } else {
                sourceRequest.loader.remove();
            }
        }

        var requestIndex = this.findRequestId(sourceRequest.request);
        sourceRequest.cmduid = null;
        sourceRequest.request = null;
        sourceRequest.cmd = null;
        sourceRequest.data = null;
        sourceRequest.onComplete = null;
        sourceRequest.onError = null;
        sourceRequest.loader = null;
        sourceRequest.loaderTarget = null;
        sourceRequest.allowUserCancel = null;
        sourceRequest.contentType = null;
        sourceRequest.timeOut = null;
        sourceRequest.passData = null;

        if (requestIndex != null) this.requests.splice(requestIndex, 1);

        sourceRequest = null;
    }


    guid () {
        function s4() {
          return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
        }
        return s4() + s4() + '-' + s4();
    }

    findRequest(request) {
        for (let index = 0; index < this.requests.length; index++) {
            if (request == this.requests[index].request) return this.requests[index];
        }
        return null;
    }

    findRequestId(request) {
        for (let index = 0; index < this.requests.length; index++) {
            if (request == this.requests[index].request) return index;
        }
        return null;
    }

    createLoader(relativeTo) {
        var dom =   '<div class="loaderBox">'+
                        '<div class="showbox">'+
                            '<div class="loader">'+
                                '<svg class="circular" viewBox="25 25 50 50">'+
                                    '<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>'+
                                '</svg>'+
                            '</div>'+
                        '</div>'+
                    '</div>';

        return $(dom).appendTo(relativeTo);
    }

}
