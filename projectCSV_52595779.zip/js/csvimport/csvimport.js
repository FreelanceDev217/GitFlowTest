class CsvImport {


    constructor(targetList = null, stafflist = null, databasefields = [], importCompleteCallback = null, cancelCallback = null) {

        // callback functions
        this.importCompleteCallback = importCompleteCallback;
        this.cancelCallback = cancelCallback;


        // language
        this.lang = {
            cancel: 'CANCEL',
            selectfile: 'Click to select the CSV file to import',
            csvfileinfo: 'The CSV file must use the UTF8 code',
            labelcolumndelimiter: 'Column delimiter:',
            labeltextescape: 'Text escape:',
            labelAssignStaff: 'Assign all importation to:',
            labelStartImport: 'Import',
        };


        // bind functions
        this.onFileSelected = this.onFileSelected.bind(this);
        this.continueCsvLoading = this.continueCsvLoading.bind(this);
        this.onSettingChange = this.onSettingChange.bind(this);
        this.onBtStartImport = this.onBtStartImport.bind(this);



        // variables
        this.targetList = targetList;
        this.staffList = stafflist;
        this.databasefields = databasefields;
        this.csvFileContent = '';


        this.window = null;


        // DOM
        this.domx = $(`
            <div class="popupcsvimport pagestart">

                <div class="csvpage pagestart">
                    <button class="btSelectFile k-primary k-button">${this.lang.selectfile}</button>
                    <span class="infolabel">${this.lang.csvfileinfo}</span>
                    <button class="btCancel k-button">${this.lang.cancel}</button>
                </div>

                <div class="csvpage pagesetting">
                    <div class="column1"><input class="fakSelectFixed select_columndelimiter"/></div>
                    <div class="column2"><input class="fakSelectFixed select_textexcape"/></div>
                    <div class="column3"><input class="fakSelectFixed select_assignstaff"/></div>
                    <div class="column4"><input class="fakSelectFixed select_assignTargetList"/></div>
                    <div class="grid"></div>
                    <button class="btDoImport k-primary k-button">${this.lang.labelStartImport}</button>
                    <button class="btCancel k-button">${this.lang.cancel}</button>
                </div>

                <div class="csvpage pageimporting">

                </div>

                <div class="csvpage pagefinish">

                </div>

            </div>
        `);


        // dom element
        this.selectColumnDelimiter = this.domx.find('.select_columndelimiter');
        this.selectTextExcape = this.domx.find('.select_textexcape');
        this.selectAssignStaff = this.domx.find('.select_assignstaff');
        this.selectAssignTargetList = this.domx.find('.select_assignTargetList');
        this.grid = this.domx.find('.grid');


        // attach event
        this.domx.find('.btSelectFile').on('click', (e)=>{ this.fileInput.click(); });
        this.domx.find('.btDoImport').on('click', this.onBtStartImport );



        // initialisation
        this.fileInput = document.createElement( 'input' );
        this.fileInput.type = 'file';
        this.fileInput.accept="text/csv";
        $(this.fileInput).prop('accept', ".csv,text/csv");
        this.fileInput.addEventListener( 'change', this.onFileSelected );


        this.initPopup();
    }


    /* Open the popup */
    initPopup() {

        this.selectColumnDelimiter.kendoDropDownList({
            dataTextField: "label",
            dataValueField: "value",
            dataSource: [
                {label: '; Semi-colon', value: 'semicolon'},
                {label: ', Comma', value: 'comma'},
                {label: 'Tabulation', value: 'tab'},
                {label: 'Space', value: 'space'},

            ],
            select: this.onSettingChange,
        });
        this.selectTextExcape.kendoDropDownList({
            dataTextField: "label",
            dataValueField: "value",
            dataSource: [
                {label: 'no delimiter', value: ''},
                {label: '" quote', value: '"'},

            ],
            select: this.onSettingChange,
        });
        this.selectAssignStaff.kendoDropDownList({
            dataSource: this.staffList,
            select: this.onSettingChange,
            valueTemplate: `#: prenom # #: nom #`,
            template: `#: prenom # #: nom #`,
            dataValueField: "id",
        });

        this.selectAssignTargetList.kendoDropDownList({
            autoBind: false,
            dataSource: this.targetList,
            select: this.onSettingChange,
            dataTextField: "listname",
            dataValueField: "id",
        });

        

        this.grid.kendoGrid();

        this.window = this.domx.kendoWindow({
            title: 'CSV Importation',
            resizable: false,
            appendTo: "body",
            modal: true,
            width: '890px',
            height: '500px',
        }).data("kendoWindow");


        this.window.center().open();
    }


    /* a file has been selected: check if it's valid and load it */
    onFileSelected(event) {
        if (this.fileInput.files.length == 0) return;
        
        var filename = this.fileInput.files[0].name;
        var extension = filename.split( '.' ).pop().toLowerCase();

        var reader = new FileReader();
        reader.onload = (event) => {
            this.csvFileContent = $.trim(event.target.result);
            if (this.csvFileContent !== '') this.continueCsvLoading();
        }

        reader.readAsText(this.fileInput.files[0]); // can add file encoding if different than UTF8

    }


    /* a file has been loaded into this.csvFileContent */
    continueCsvLoading() {
        this.domx.flipclas
        this.domx.removeClass('pagestart').addClass('pagesetting');
    }

    onSettingChange(e) {
        // csv setting has changed, apply the modification to the preview grid
    }

    onBtStartImport(e) {
        // process the importation
    }


    importBatch() {

    }




}